<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Greenery" tilewidth="8" tileheight="8" tilecount="784" columns="28">
 <image source="../IMAGES/Unknown.jpeg" width="225" height="224"/>
</tileset>
